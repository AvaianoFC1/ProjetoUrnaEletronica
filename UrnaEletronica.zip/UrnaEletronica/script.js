// No JavaScript, cria uma variável através da palavra-chave let nomedavariável, que armazena: documento.querySelector('nomedadiv');
// Ou seja: no documento, chama o método Seletor de Consulta (nome da div)
let seuVotoPara = document.querySelector('.d-1-1 span');
let cargo = document.querySelector('d-1-2 span');
let descricao = document.querySelector('d-1-4 span');
let aviso = document.querySelector('d-1-2 span');
let lateral = document.querySelector('d-1-right');
let numeros = document.querySelector('d-1-3');